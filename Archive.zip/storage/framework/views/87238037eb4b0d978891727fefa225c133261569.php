<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Person Information</h2>
        </div>
    </div>
</div>

<?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?>

<form class="row g-3">
    <div class="col-auto">
        <label for="birth-year" class="visually-hidden">Birth year</label>
        <input type="text" class="form-control" id="birth-year" name='birth_year' placeholder="Year">
    </div>
    <div class="col-auto">
      <label for="birth-month" class="visually-hidden">Birth month</label>
      <input type="text" class="form-control" id="birth-month" name='birth_month' placeholder="Month">
    </div>
    <div class="col-auto">
      <button type="submit" class="btn btn-primary mb-3">Filter</button>
    </div>
</form>

<table class="table table-bordered">
    <tr>
        <th>ID</th>
        <th>Email Address</th>
        <th>Name</th>
        <th>Birthday</th>
        <th>Phone</th>
        <th>Country</th>
    </tr>
    <?php $__currentLoopData = $personInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e(++$i); ?></td>
        <td><?php echo e($item->email); ?></td>
        <td><?php echo e($item->name); ?></td>
        <td><?php echo e($item->birthday); ?></td>
        <td><?php echo e($item->phone); ?></td>
        <td><?php echo e($item->country); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php echo $personInfo->links(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/eastnetic/resources/views/persons/index.blade.php ENDPATH**/ ?>